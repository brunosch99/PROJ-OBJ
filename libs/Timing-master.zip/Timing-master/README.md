A simple timer class for Arduino - no interrupts, no overflow problems. 2 options,
one of which catches up if late, the other does not.

For more on IOT, Arduino, ESP8266 and Raspberry Pi visit http://tech.scargill.net

